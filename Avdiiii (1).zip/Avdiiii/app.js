/* ═══════════════════════════════════════════════════════════════
   AVDHI — Senior Video Editor & Motion Designer
   Interactive JavaScript Architecture (yanxinzhang.com reference)
   - Luxury Editorial Waterfall Scramble (Zero Jitter, Elegant Rolling)
   - 3D Perspective Orbit Space (Media Reference Implementation)
   - Curated Categorical Work Showcase (16:9 Cinema & 9:16 Reels)
   - Scroll-Linked Unblur Manifesto
   - Director's Theater Lightbox
   - Kinetic Smart Cursor Follower
   ═══════════════════════════════════════════════════════════════ */

'use strict';

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* Podcast YouTube IDs */
const PODCAST_IDS = ['N-Jz4bVRX7g', 'PobaFK3snUU', 'es8H212fXVs', '-KzaSDQVMXg'];

/* ── 1. LUXURY EDITORIAL WATERFALL SCRAMBLE ──────────────────── */
function initWaterfallScramble() {
  const headline = $('#heroHeadline');
  if (!headline) return;

  const chars = $$('.scramble-char', headline);
  if (!chars.length) return;

  // Clean, high-end alphanumeric character pool
  const CHAR_POOL = ['A', 'V', 'D', 'H', 'I', 'M', 'O', 'T', 'X', 'R', 'K', '8', '0'];
  const NARROW_POOL = ['i', 'l', '1', 'I', 't', 'r'];

  function rollChar(el, delay = 0) {
    const finalChar = el.dataset.final || el.textContent;
    if (finalChar === ',' || finalChar === "'") return;

    let step = 0;
    const totalSteps = 4 + Math.floor(Math.random() * 3);
    const pool = (finalChar === 'i' || finalChar === 'I') ? NARROW_POOL : CHAR_POOL;

    setTimeout(() => {
      el.classList.add('is-shuffling');
      const interval = setInterval(() => {
        if (step >= totalSteps) {
          el.textContent = finalChar;
          el.classList.remove('is-shuffling');
          clearInterval(interval);
        } else {
          el.textContent = pool[Math.floor(Math.random() * pool.length)];
          step++;
        }
      }, 48);
    }, delay);
  }

  // Smooth cascading entrance waterfall across the characters on load
  function triggerWaterfallWave() {
    chars.forEach((charEl, idx) => {
      rollChar(charEl, idx * 55);
    });
  }

  // Run once after initial page appearance
  setTimeout(triggerWaterfallWave, 350);

  // Interactive hover: individual character rolls smoothly when cursor glides over it
  chars.forEach((charEl) => {
    charEl.addEventListener('mouseenter', () => {
      rollChar(charEl, 0);
    });
  });
}

/* ── 2. 3D CAMERA SPACE: ORBIT PERSPECTIVE TILT ───────────────── */
function init3DCameraOrbit() {
  const scene = $('.clients-3d-scene');
  const orbitSpace = $('#c3dOrbitSpace');
  if (!scene || !orbitSpace) return;

  let mouseX = 0, mouseY = 0;
  let currentRotX = 0, currentRotY = 0;
  let targetRotX = 0, targetRotY = 0;
  let isHovered = false;

  scene.addEventListener('mousemove', e => {
    const rect = scene.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;

    targetRotY = x * 26;   // rotate around Y axis (-13 to +13 deg)
    targetRotX = -y * 20;  // rotate around X axis (-10 to +10 deg)
    isHovered = true;
  });

  scene.addEventListener('mouseleave', () => {
    isHovered = false;
    targetRotX = 0;
    targetRotY = 0;
  });

  // Smooth RAF lerp loop with subtle idle breathing
  let angle = 0;
  function update3D() {
    angle += 0.015;

    if (!isHovered) {
      const idleX = Math.sin(angle) * 2.5;
      const idleY = Math.cos(angle * 0.8) * 4;
      currentRotX += (idleX - currentRotX) * 0.05;
      currentRotY += (idleY - currentRotY) * 0.05;
    } else {
      currentRotX += (targetRotX - currentRotX) * 0.12;
      currentRotY += (targetRotY - currentRotY) * 0.12;
    }

    orbitSpace.style.transform = `rotateX(${currentRotX.toFixed(2)}deg) rotateY(${currentRotY.toFixed(2)}deg)`;
    requestAnimationFrame(update3D);
  }

  requestAnimationFrame(update3D);

  // Click handler for 3D cards
  $$('.c3d-card', orbitSpace).forEach(card => {
    card.addEventListener('click', () => {
      if (window.openTheaterVideo) {
        window.openTheaterVideo(card);
      }
    });
  });
}

/* ── 3. CURATED THREE-SECTION WORK SHOWCASE ───────────────────── */
function initWorkShowcase() {
  if (!window.PORTFOLIO_PROJECTS) return;

  const all = window.PORTFOLIO_PROJECTS;

  const motionItems = all.filter(p => p.category === 'motion-ai' || p.category === 'motion_ai' || p.category === 'motion-graphics' || p.category === 'ai-videos');
  const longItems = all.filter(p => p.category === 'long-form' || p.category === 'long_form');
  const shortItems = all.filter(p => p.category === 'short-form' || p.category === 'short_form');

  const gridMotion = $('#gridMotionAI');
  const gridLong   = $('#gridLongForm');
  const gridShort  = $('#gridShortForm');

  const btnLong  = $('#btnLoadMoreLong');
  const btnShort = $('#btnLoadMoreShort');

  let isLongExpanded  = false;
  let isShortExpanded = false;

  function createCardHTML(item, isVertical) {
    const thumb = item.thumbnail || (item.youtubeId
      ? `https://i.ytimg.com/vi/${item.youtubeId}/maxresdefault.jpg`
      : 'images/jKSWb8nhDHekUUhy7TU93bZUo.jpg');
    const duration = item.duration || (isVertical ? '00:45' : '12:40');
    const fps = item.fps || (isVertical ? '60 FPS' : '24 FPS');
    const res = item.resolution || (isVertical ? '1080x1920' : '4K UHD');
    const tools = Array.isArray(item.tools) ? item.tools.join(' · ') : (item.tools || 'Premiere Pro · After Effects');

    return `
      <article class="proj-card"
               data-category="${item.category || ''}"
               data-youtube="${item.youtubeId || ''}"
               data-vimeo="${item.vimeoId || ''}"
               data-url="${item.url || ''}"
               data-title="${item.title || 'Untitled'}"
               data-client="${item.client || 'Commercial Production'}"
               data-fps="${fps}"
               data-res="${res}"
               data-aspect="${isVertical ? '9:16' : (item.aspectRatio || '16:9')}"
               tabindex="0"
               role="button"
               aria-label="Play video: ${item.title || ''}">
        <div class="proj-media">
          <img src="${thumb}" alt="${item.title || ''}" class="proj-thumb" loading="lazy" onerror="this.src='images/jKSWb8nhDHekUUhy7TU93bZUo.jpg'">
          <span class="proj-badge-top-left">${duration}</span>
          <span class="proj-badge-top-right">${fps}</span>
          <div class="proj-overlay">
            <div class="proj-play-circle">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                <polygon points="6,3 20,12 6,21"></polygon>
              </svg>
            </div>
          </div>
        </div>
        <div class="proj-info">
          <div class="proj-text-col">
            <h4 class="proj-title">${item.title || 'Untitled'}</h4>
          </div>
          <div class="proj-arrow-btn" aria-hidden="true">↗</div>
        </div>
      </article>
    `;
  }

  function renderMotion() {
    if (!gridMotion) return;
    gridMotion.innerHTML = motionItems.map(p => createCardHTML(p, false)).join('');
  }

  function renderLong() {
    if (!gridLong) return;
    const items = isLongExpanded ? longItems : longItems.slice(0, 6);
    gridLong.innerHTML = items.map(p => createCardHTML(p, false)).join('');
    if (btnLong) {
      btnLong.textContent = isLongExpanded
        ? 'Show Less ↑'
        : `Show All Long Form (${longItems.length}) ↓`;
    }
  }

  function renderShort() {
    if (!gridShort) return;
    gridShort.innerHTML = shortItems.map(p => createCardHTML(p, true)).join('');
  }

  btnLong?.addEventListener('click', () => {
    isLongExpanded = !isLongExpanded;
    renderLong();
  });

  renderMotion();
  renderLong();
  renderShort();

  // Smooth jump navigation and ScrollSpy
  const navPills = $$('.work-filters .filter-btn');
  const sections = [
    $('#section-motion-ai'),
    $('#section-long-form'),
    $('#section-short-form')
  ].filter(Boolean);

  navPills.forEach(pill => {
    pill.addEventListener('click', e => {
      const targetId = pill.getAttribute('href');
      if (targetId && targetId.startsWith('#')) {
        const targetEl = $(targetId);
        if (targetEl) {
          e.preventDefault();
          targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
          navPills.forEach(p => p.classList.remove('is-active'));
          pill.classList.add('is-active');
        }
      }
    });
  });

  if (window.IntersectionObserver && sections.length) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.id;
          navPills.forEach(p => {
            const matches = p.getAttribute('href') === `#${id}`;
            p.classList.toggle('is-active', matches);
          });
        }
      });
    }, { rootMargin: '-15% 0px -55% 0px', threshold: 0 });

    sections.forEach(s => observer.observe(s));
  }
}

/* ── 4. SCROLL-LINKED UNBLUR MANIFESTO ───────────────────────── */
function initManifestoReveal() {
  const words = $$('#aboutManifesto .word');
  if (!words.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        words.forEach((w, idx) => {
          setTimeout(() => {
            w.classList.add('is-revealed');
          }, idx * 30);
        });
        observer.disconnect();
      }
    });
  }, { threshold: 0.2 });

  const manifesto = $('#aboutManifesto');
  if (manifesto) observer.observe(manifesto);
}

/* ── 5. "WHAT I DO*" SERVICES ACCORDION ──────────────────────── */
function initServicesAccordion() {
  const items = $$('.service-item');
  items.forEach(item => {
    const header = item.querySelector('.service-header');
    if (!header) return;
    header.addEventListener('click', () => {
      const isOpen = item.classList.contains('is-open');
      items.forEach(i => i.classList.remove('is-open'));
      if (!isOpen) item.classList.add('is-open');
    });
  });
}

/* ── 6. DIRECTOR'S THEATER LIGHTBOX ──────────────────────────── */
function initTheaterLightbox() {
  const dialog   = $('#theaterDialog');
  const box      = $('#theaterBox');
  const screen   = $('#thScreen');
  const title    = $('#thTitle');
  const client   = $('#thClient');
  const fps      = $('#thFps');
  const res      = $('#thRes');
  const aspect   = $('#thAspect');
  const closeBtn = $('#thClose');

  if (!dialog || !screen) return;

  function open(src) {
    const yt = src.dataset.youtube;
    const vimeo = src.dataset.vimeo;
    const behance = src.dataset.behance;
    const url = src.dataset.url;

    if (!yt && !vimeo && !behance) {
      if (url) {
        window.open(url, '_blank', 'noopener,noreferrer');
      }
      return;
    }

    const isVert = src.dataset.aspect === '9:16';
    box.classList.toggle('is-vertical', isVert);

    title.textContent  = src.dataset.title  || 'Avdhi Showcase';
    client.textContent = src.dataset.client || 'Client Production';
    fps.textContent    = src.dataset.fps    || '24 FPS';
    res.textContent    = src.dataset.res    || '4K UHD';
    aspect.textContent = src.dataset.aspect || '16:9';

    const extLink = $('#thExtLink');
    if (extLink) {
      if (url) {
        extLink.href = url;
        extLink.style.display = 'inline-flex';
        extLink.textContent = behance ? 'View on Behance ↗' : (vimeo ? 'View on Vimeo ↗' : 'View Source ↗');
      } else {
        extLink.style.display = 'none';
      }
    }

    if (yt) {
      screen.innerHTML = `
        <iframe src="https://www.youtube.com/embed/${yt}?autoplay=1&rel=0&modestbranding=1"
                allow="autoplay; fullscreen; encrypted-media"
                allowfullscreen
                title="${src.dataset.title || 'Video Player'}"></iframe>
      `;
    } else if (vimeo) {
      screen.innerHTML = `
        <iframe src="https://player.vimeo.com/video/${vimeo}?autoplay=1"
                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                allowfullscreen
                title="${src.dataset.title || 'Video Player'}"></iframe>
      `;
    } else if (behance) {
      screen.innerHTML = `
        <iframe src="https://www.behance.net/embed/project/${behance}?ilo0=1"
                allow="autoplay; fullscreen; clipboard-write"
                allowfullscreen
                title="${src.dataset.title || 'Behance Project'}"></iframe>
      `;
    }

    dialog.showModal();
    document.body.style.overflow = 'hidden';
  }

  function close() {
    screen.innerHTML = '';
    dialog.close();
    document.body.style.overflow = '';
  }

  window.openTheaterVideo = open;

  // Hero centerpiece trigger
  const heroCard = $('#heroCenterpiece');
  if (heroCard) {
    heroCard.addEventListener('click', () => open(heroCard));
    heroCard.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(heroCard); }
    });
  }

  // Project cards delegation
  document.addEventListener('click', e => {
    const card = e.target.closest('.proj-card, .c3d-card');
    if (card && (card.dataset.youtube || card.dataset.vimeo || card.dataset.behance || card.dataset.url)) open(card);
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') {
      const card = e.target.closest('.proj-card, .c3d-card');
      if (card && (card.dataset.youtube || card.dataset.vimeo || card.dataset.behance || card.dataset.url)) { e.preventDefault(); open(card); }
    }
  });

  closeBtn?.addEventListener('click', close);
  dialog.addEventListener('click', e => { if (e.target === dialog) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && dialog.open) close(); });
}

/* ── 7. ONE-CLICK EMAIL COPY ─────────────────────────────────── */
function initEmailCopy() {
  const btn = $('#btnCopyEmail');
  const toast = $('#copyToast');
  if (!btn || !toast) return;

  btn.addEventListener('click', () => {
    navigator.clipboard?.writeText('avdhikc@gmail.com').then(() => {
      toast.classList.add('is-show');
      setTimeout(() => toast.classList.remove('is-show'), 2200);
    }).catch(() => {
      window.location.href = 'mailto:avdhikc@gmail.com';
    });
  });
}

/* ── 8. KINETIC SMART CURSOR ─────────────────────────────────── */
function initSmartCursor() {
  if (window.matchMedia('(hover: none), (pointer: coarse)').matches) return;

  const cursor = $('#smartCursor');
  const text = $('#cursorText');
  if (!cursor || !text) return;

  let mouseX = -100, mouseY = -100;
  let curX = -100, curY = -100;
  let isVisible = false;

  window.addEventListener('pointermove', e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    if (!isVisible) {
      isVisible = true;
      cursor.style.opacity = '1';
    }
  }, { passive: true });

  document.addEventListener('mouseleave', () => {
    isVisible = false;
    cursor.style.opacity = '0';
  });

  function loop() {
    if (isVisible) {
      curX += (mouseX - curX) * 0.18;
      curY += (mouseY - curY) * 0.18;
      cursor.style.transform = `translate3d(${curX}px, ${curY}px, 0) translate(-50%, -50%)`;
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  document.addEventListener('mouseover', e => {
    const videoTarget = e.target.closest('.proj-card, .hero-screen-wrap, .c3d-card');
    const interactive = e.target.closest('a, button, .service-item, .client-logo-item, .inline-badge');

    if (videoTarget) {
      cursor.classList.add('is-play');
      cursor.classList.remove('is-hover');
    } else if (interactive) {
      cursor.classList.add('is-hover');
      cursor.classList.remove('is-play');
    } else {
      cursor.classList.remove('is-play', 'is-hover');
    }
  }, { passive: true });
}

/* ── INITIALIZATION ──────────────────────────────────────────── */
function init() {
  initWaterfallScramble();
  init3DCameraOrbit();
  initWorkShowcase();
  initManifestoReveal();
  initServicesAccordion();
  initTheaterLightbox();
  initEmailCopy();
  initSmartCursor();
}

document.readyState === 'loading'
  ? document.addEventListener('DOMContentLoaded', init)
  : init();
